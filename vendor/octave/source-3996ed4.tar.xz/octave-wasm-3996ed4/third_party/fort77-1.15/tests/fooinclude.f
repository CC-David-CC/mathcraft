      INCLUDE 'foo.inc'
